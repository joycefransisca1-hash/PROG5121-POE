package uservalidation;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Login login = new Login();

        // Get user input
        System.out.print("Enter username: ");
        String enteredUsername = input.nextLine();

        System.out.print("Enter password: ");
        String enteredPassword = input.nextLine();

        System.out.print("Enter cell number: ");
        String cellNumber = input.nextLine();

        // Stored values (for login check)
        String storedUsername = enteredUsername;
        String storedPassword = enteredPassword;

        // Username check
        if (login.checkUsername(enteredUsername)) {
            System.out.println("Username successfully captured");
        } else {
            System.out.println("Username is incorrectly formatted");
        }

        // Password check
        if (login.checkPassword(enteredPassword)) {
            System.out.println("Password successfully captured");
        } else {
            System.out.println("Password does not meet complexity requirements");
        }

        // Cell number check
        if (login.checkCellPhoneNumber(cellNumber)) {
            System.out.println("Cell phone number successfully captured");
        } else {
            System.out.println("Cell phone number incorrectly formatted");
        }

        // Login check (simple demo login)
        if (login.loginUser(storedUsername, storedPassword,
                enteredUsername, enteredPassword)) {

            System.out.println("Login successful");
        } else {
            System.out.println("Login failed");
        }
    }
}