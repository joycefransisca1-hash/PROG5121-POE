package uservalidation;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Login login = new Login();

        // Stored credentials for login check
        String storedUsername = "";
        String storedPassword = "";

        // -------- REGISTRATION --------
        boolean registered = false;
        while (!registered) {

            System.out.print("Enter username: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine();

            System.out.print("Enter cell number: ");
            String cellNumber = scanner.nextLine();

            // Username check
            if (!login.checkUsername(enteredUsername)) {
                System.out.println("Username is incorrectly formatted.");
                System.out.println("Username must contain '_' and be 5 characters or less.");
                continue;
            }

            // Password check
            if (!login.checkPassword(enteredPassword)) {
                System.out.println("Password does not meet complexity requirements.");
                System.out.println("Must be 8+ characters, contain uppercase, number and special character.");
                continue;
            }

            // Cell number check
            if (!login.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell phone number incorrectly formatted.");
                System.out.println("Must start with 0 and be 10 digits long.");
                continue;
            }

            // Store credentials once all checks pass
            storedUsername = enteredUsername;
            storedPassword = enteredPassword;
            registered = true;

            System.out.println("Username successfully captured");
            System.out.println("Password successfully captured");
            System.out.println("Cell phone number successfully captured");
            System.out.println("Registration successful.");
        }

        // -------- LOGIN --------
        boolean loggedIn = false;
        while (!loggedIn) {

            System.out.print("Enter username: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine();

            if (login.loginUser(storedUsername, storedPassword, enteredUsername, enteredPassword)) {
                System.out.println("Login successful.");
                loggedIn = true;
            } else {
                System.out.println("Login failed. Incorrect details.");
            }
        }

        // -------- WELCOME MESSAGE --------
        System.out.println("Welcome to QuickChat.");

        // -------- NUMBER OF MESSAGES --------
        int numMessages = 0;
        while (numMessages <= 0) {

            System.out.print("How many messages would you like to send? ");

            String input = scanner.nextLine();

            try {
                numMessages = Integer.parseInt(input);

                if (numMessages <= 0) {
                    System.out.println("Please enter a number greater than 0.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        // -------- MAIN MENU LOOP --------
        boolean running = true;
        int messagesSentSoFar = 0;

        while (running) {

            System.out.println("\n=== QuickChat Menu ===");
            System.out.println("1. Send Messages");
            System.out.println("2. Show Recently Sent Messages");
            System.out.println("3. Quit");
            System.out.print("Select an option: ");

            int menuChoice;

            try {
                menuChoice = Integer.parseInt(scanner.nextLine()) - 1;
            } catch (NumberFormatException e) {
                menuChoice = -1;
            }

            switch (menuChoice) {

                // -------- OPTION 1: SEND MESSAGES --------
                case 0:

                    if (messagesSentSoFar >= numMessages) {
                        System.out.println(
                                "You have reached your message limit of "
                                        + numMessages + ".");
                        break;
                    }

                    System.out.print("Enter recipient cell number: ");
                    String recipient = scanner.nextLine();

                    System.out.print("Enter your message: ");
                    String messageText = scanner.nextLine();

                    // Validate message length
                    if (messageText.length() > 250) {
                        int over = messageText.length() - 250;

                        System.out.println(
                                "Message exceeds 250 characters by "
                                        + over +
                                        "; please reduce the size.");
                        break;
                    }

                    // Create message object
                    Message message = new Message(recipient, messageText);

                    // Validate recipient
                    String recipientCheck = message.checkRecipientCell();
                    System.out.println(recipientCheck);

                    if (!recipientCheck.equals("Cell phone number successfully captured.")) {
                        break;
                    }

                    // Send, store or disregard
                    String outcome = message.sentMessage();
                    System.out.println(outcome);

                    // Display full message details if sent
                    if (outcome.equals("Message successfully sent.")) {

                        messagesSentSoFar++;

                        System.out.println("\n--- Message Details ---");
                        System.out.println("Message ID   : " + message.getMessageID());
                        System.out.println("Message Hash : " + message.getMessageHash());
                        System.out.println("Recipient    : " + message.getRecipient());
                        System.out.println("Message      : " + message.getMessageText());
                    }

                    // Display total when limit reached
                    if (messagesSentSoFar == numMessages) {
                        System.out.println("All messages sent!");
                        System.out.println("Total messages sent: "
                                + Message.returnTotalMessages());
                    }

                    break;

                // -------- OPTION 2: SHOW RECENTLY SENT --------
                case 1:
                    System.out.println("Coming Soon.");
                    break;

                // -------- OPTION 3: QUIT --------
                case 2:
                    System.out.println(
                            "Total messages sent: "
                                    + Message.returnTotalMessages()
                                    + "\nGoodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Please select a valid option.");
                    break;
            }
        }

        scanner.close();
    }
}