package uservalidation;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Message {

    // -------- MESSAGE FIELDS --------
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // -------- SHARED MESSAGE STORE --------
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static int messageCount = 0;

    // Constructor builds message and auto-generates ID, number and hash
    public Message(String recipient, String messageText) {
        messageCount++;
        this.messageID      = generateMessageID();
        this.messageNumber  = messageCount;
        this.recipient      = recipient;
        this.messageText    = messageText;
        this.messageHash    = createMessageHash();
    }

    // Generates a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long)(rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // Checks message ID is not more than 10 characters
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Checks recipient cell number starts with international code
    public String checkRecipientCell() {
        if (!recipient.startsWith("+")) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        return "Cell phone number successfully captured.";
    }

    // Creates and returns the message hash
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "");

        return (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // Checks message does not exceed 250 characters
    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int over = messageText.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    // Allows user to send, disregard or store the message
    public String sentMessage() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message");
        System.out.print("Select option: ");

        int choice;

        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return "No option selected.";
        }

        switch (choice) {

            case 1:
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";

            case 2:
                return "Press 0 to delete the message.";

            case 3:
                storeMessage();
                return "Message successfully stored.";

            default:
                return "No option selected.";
        }
    }

    // Returns all sent messages as a formatted string
    public static String printMessages() {

        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }

        StringBuilder sb = new StringBuilder();

        for (Message m : sentMessages) {
            sb.append("Message ID   : ").append(m.messageID).append("\n");
            sb.append("Message Hash : ").append(m.messageHash).append("\n");
            sb.append("Recipient    : ").append(m.recipient).append("\n");
            sb.append("Message      : ").append(m.messageText).append("\n");
            sb.append("----------------------------\n");
        }

        return sb.toString();
    }

    // Returns total number of messages sent
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Stores message as a JSON entry in messages.json
    public void storeMessage() {

        String json = "{\n" +
                "  \"messageID\": \"" + messageID + "\",\n" +
                "  \"messageHash\": \"" + messageHash + "\",\n" +
                "  \"recipient\": \"" + recipient + "\",\n" +
                "  \"message\": \"" + messageText + "\"\n" +
                "}";

        try {
            java.io.FileWriter fw = new java.io.FileWriter("messages.json", true);
            fw.write(json + ",\n");
            fw.close();

        } catch (java.io.IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // Getters
    public String getMessageID()     { return messageID; }
    public String getRecipient()     { return recipient; }
    public String getMessageText()   { return messageText; }
    public String getMessageHash()   { return messageHash; }
    public int getMessageNumber()    { return messageNumber; }
}
