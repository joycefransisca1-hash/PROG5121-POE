package uservalidation;

public class Login {

    // Username must contain "_" and be <= 5 characters
    public boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Password must:
    // - be at least 8 characters
    // - contain uppercase letter
    // - contain number
    // - contain special character
    public boolean checkPassword(String password) {

        if (password.length() < 8) {
            return false;
        }

        boolean hasUppercase = password.matches(".*[A-Z].*");
        boolean hasNumber = password.matches(".*\\d.*");
        boolean hasSpecialChar = password.matches(".*[^a-zA-Z0-9].*");

        return hasUppercase && hasNumber && hasSpecialChar;
    }

    // Regex cell phone validation (REQUIRED by rubric)
    // Must start with 0 and be 10 digits long
    public boolean checkCellPhoneNumber(String cellNumber) {
        return cellNumber.matches("^0\\d{9}$");
    }

    // Login authentication (username + password match)
    public boolean loginUser(String storedUsername, String storedPassword,
                             String enteredUsername, String enteredPassword) {

        return storedUsername.equals(enteredUsername)
                && storedPassword.equals(enteredPassword);
    }
}