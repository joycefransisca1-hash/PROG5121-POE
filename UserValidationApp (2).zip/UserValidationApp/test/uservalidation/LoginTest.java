/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package uservalidation;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    Login login = new Login();

    @Test
    public void testCheckUsername() {
        assertEquals(true, login.checkUsername("ab_c"));
        assertEquals(false, login.checkUsername("abcdef"));
    }

    @Test
    public void testCheckPassword() {
        assertEquals(true, login.checkPassword("Password1!"));
        assertEquals(false, login.checkPassword("pass"));
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertEquals(true, login.checkCellPhoneNumber("0821234567"));
        assertEquals(false, login.checkCellPhoneNumber("12345"));
    }

    @Test
    public void testLoginUser() {
        assertEquals(true,
            login.loginUser("ab_c", "Password1!", "ab_c", "Password1!"));

        assertEquals(false,
            login.loginUser("ab_c", "Password1!", "wrong", "wrong"));
    }
}