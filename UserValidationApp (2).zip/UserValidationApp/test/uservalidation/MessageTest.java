package uservalidation;

import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.reflect.Field;

public class MessageTest {

    public MessageTest() {
    }

    // Test: Message ID is not more than 10 characters
    @Test
    public void testCheckMessageID() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertTrue("Message ID generated: " + msg.getMessageID(), msg.checkMessageID());
    }

    // Test: Recipient cell - success (starts with +)
    @Test
    public void testCheckRecipientCell() {
        Message validMsg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Cell phone number successfully captured.", validMsg.checkRecipientCell());
    }

    // Test: Recipient cell - failure (no international code)
    @Test
    public void testCheckRecipientCellFail() {
        Message invalidMsg = new Message("08575975889", "Hi Keegan, did you receive the payment?");
        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                invalidMsg.checkRecipientCell()
        );
    }

    // Test: Message hash is correct
    @Test
    public void testCreateMessageHash() throws Exception {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        // Force known messageID using reflection
        Field idField = Message.class.getDeclaredField("messageID");
        idField.setAccessible(true);
        idField.set(msg, "0012345678");

        // Get messageNumber
        Field numField = Message.class.getDeclaredField("messageNumber");
        numField.setAccessible(true);
        int msgNum = (int) numField.get(msg);

        // Recalculate hash
        Field hashField = Message.class.getDeclaredField("messageHash");
        hashField.setAccessible(true);
        hashField.set(msg, msg.createMessageHash());

        String expectedHash = "00:" + msgNum + ":HITONIGHT";

        assertEquals(expectedHash, msg.getMessageHash());
    }

    // Test: Message length success
    @Test
    public void testCheckMessageLength() {
        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertEquals("Message ready to send.",
                msg.checkMessageLength());
    }

    // Test: Message length failure
    @Test
    public void testCheckMessageLengthFail() {

        String longMessage = "A".repeat(260);

        Message msg = new Message("+27718693002", longMessage);

        int over = 260 - 250;

        assertEquals(
                "Message exceeds 250 characters by " + over + "; please reduce the size.",
                msg.checkMessageLength()
        );
    }

    // Test: Sent message text
    @Test
    public void testSentMessage() {

        String expected = "Message successfully sent.";

        assertNotNull(expected);
        assertEquals("Message successfully sent.", expected);
    }

    // Test: Disregard message text
    @Test
    public void testSentMessageDisregard() {

        String expected = "Press 0 to delete the message.";

        assertNotNull(expected);
        assertEquals("Press 0 to delete the message.", expected);
    }

    // Test: Store message text
    @Test
    public void testSentMessageStore() {

        String expected = "Message successfully stored.";

        assertNotNull(expected);
        assertEquals("Message successfully stored.", expected);
    }

    // Test: Print messages result is not null
    @Test
    public void testPrintMessages() {

        String result = Message.printMessages();

        assertNotNull("printMessages() should not return null.",
                result);
    }

    // Test: Total messages is 0 or more
    @Test
    public void testReturnTotalMessages() {

        int total = Message.returnTotalMessages();

        assertTrue("Total messages should be 0 or more.",
                total >= 0);
    }

    // Test: Store message creates JSON file
    @Test
    public void testStoreMessage() {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        try {

            msg.storeMessage();

            java.io.File file = new java.io.File("messages.json");

            assertTrue(
                    "JSON file should exist after storing a message.",
                    file.exists()
            );

        } catch (Exception e) {

            fail("storeMessage() threw an exception: "
                    + e.getMessage());
        }
    }

    // Test: Message ID exists and is 10 digits
    @Test
    public void testGetMessageID() {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertNotNull(msg.getMessageID());

        assertEquals(10, msg.getMessageID().length());
    }

    // Test: Recipient stored correctly
    @Test
    public void testGetRecipient() {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertEquals("+27718693002",
                msg.getRecipient());
    }

    // Test: Message text stored correctly
    @Test
    public void testGetMessageText() {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertEquals(
                "Hi Mike, can you join us for dinner tonight?",
                msg.getMessageText()
        );
    }

    // Test: Message hash exists
    @Test
    public void testGetMessageHash() {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertNotNull(
                "Message hash should not be null.",
                msg.getMessageHash()
        );
    }

    // Test: Message number greater than 0
    @Test
    public void testGetMessageNumber() {

        Message msg = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertTrue(
                "Message number should be greater than 0.",
                msg.getMessageNumber() > 0
        );
    }
}