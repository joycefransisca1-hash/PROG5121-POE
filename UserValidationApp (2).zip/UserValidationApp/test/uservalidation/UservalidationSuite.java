/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package uservalidation;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author loren
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({uservalidation.MainTest.class, uservalidation.LoginTest.class})
public class UservalidationSuite {
    
}
